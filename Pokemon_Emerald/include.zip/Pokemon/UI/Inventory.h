#pragma once
class CInventory
{
};

